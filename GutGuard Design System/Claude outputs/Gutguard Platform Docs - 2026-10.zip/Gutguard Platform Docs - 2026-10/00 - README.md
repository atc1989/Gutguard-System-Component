# Gutguard Platform Docs (October 2026)

Read in this order.

| File | What it is | Date |
|---|---|---|
| 01 - Platform Architecture v2.md | Unified platform architecture, reconciled. Replaces the devs' v1 proposal. Governs logic, gates, roles, data ownership, events, build phases. | 3 Oct 2026 |
| 02 - Architecture v2 - Annex A - Build Readiness.md | Six gaps between v2 and a working system: migration, offline QR, idempotency keys, GG Verse decision, Release 0 for GOCC (15 Oct 2026), spine merge. | 3 Oct 2026 |
| 03 - Tech Stack.md | What the current code actually uses, from package manifests and repos. Describes today, not the target. | 29 Sep 2026 |
| 04 - Design System (Compiled).md | All GutGuard Design System vault notes in one file. Source of truth is the Obsidian vault. | Oct 2026 |

Where 01/02 (target) and 03 (current code) differ, 01/02 describe what to build and 03 describes what exists today.
